---
name: image-vision
description: 让纯文本模型获得识图能力。当用户上传图片、截图、照片，或需要理解图像/图表/界面内容、提取图片中的文字（OCR）时使用。自动调用免费视觉模型将图片转为文字描述，三模型依次降级保证可用性。
license: Apache-2.0
compatibility: Requires python3, openai>=1.0, 需要外网访问 open.bigmodel.cn
metadata:
  version: "1.0"
  provider: zhipu
  fallback-chain: glm-4.6v-flash -> glm-4.1v-thinking-flash -> glm-4v-flash
---

# 图片识别

## 何时使用
- 用户上传了图片（jpg / png / webp 等格式）
- 需要读取截图、照片、图表、界面中的内容或文字（OCR）
- 需要对图像内容提问，如图表数据分析、界面描述、物体识别
- 当前对话模型不支持多模态输入时，用它把图片转成文字

## 执行步骤
1. 获取图片数据（三选一）：
   - 用户已给 base64（data URL 格式）：直接使用
   - 本地文件路径：`--file /path/to/image.jpg`
   - 图片 URL：`--url https://example.com/img.jpg`
2. 运行脚本：
   ```bash
   python scripts/vision.py --file /path/to/image.jpg --question "请描述这张图片的内容"
   ```
   或传入 base64：
   ```bash
   python scripts/vision.py --image "data:image/jpeg;base64,..." --question "图中文字是什么"
   ```
3. 脚本自动按降级链调用模型（GLM-4.6V-Flash → GLM-4.1V-Thinking-Flash → GLM-4V-Flash），
   当前模型失败（限流/超时/报错）时自动切换下一个，全部失败才报错。
4. 脚本输出 JSON：`{"provider": "...", "description": "..."}`
5. 将 `description` 中的文字描述直接作为识图结果回复用户。

## 输入输出示例
输入：
```bash
python scripts/vision.py --file screenshot.png --question "这张截图里有什么按钮？"
```
输出：
```json
{"provider": "glm-4.6v-flash", "description": "截图顶部有搜索栏，右侧有「登录」和「注册」两个按钮..."}
```

## 边界情况
- 图片超过 10MB：先用脚本 `--max-bytes` 自动压缩后再识别（脚本内置压缩逻辑）
- 全部模型失败：返回 `{"error": "..."}`，向用户说明视觉服务暂不可用
- 输出语言：跟随用户提问语言
- API Key：从同目录 `.env` 读取 `ZHIPU_API_KEY`，也可通过环境变量注入
