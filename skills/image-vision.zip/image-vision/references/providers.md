# 提供方配置说明

## 智谱开放平台（当前唯一提供方）

- **平台地址**：https://open.bigmodel.cn/
- **API 文档**：https://open.bigmodel.cn/dev/api（OpenAI 兼容格式）
- **Base URL**：`https://open.bigmodel.cn/api/paas/v4`
- **鉴权方式**：`Authorization: Bearer <ZHIPU_API_KEY>`，Key 格式为 `{id}.{secret}`

## 模型降级链

| 优先级 | 模型 | 说明 |
|---|---|---|
| 1 | `glm-4.6v-flash` | 主力模型，免费 |
| 2 | `glm-4.1v-thinking-flash` | 兜底1，免费 |
| 3 | `glm-4v-flash` | 兜底2，免费 |

按顺序调用，当前模型失败（限流/超时/报错）时自动切换下一个。

## Key 配置方式

1. **推荐**：编辑本目录 `.env` 文件中的 `ZHIPU_API_KEY`
2. 或通过环境变量注入：`set ZHIPU_API_KEY=xxx`（PowerShell）/ `export ZHIPU_API_KEY=xxx`（Linux/macOS）

## 申请新 Key（如需要）

1. 登录 https://open.bigmodel.cn/
2. 进入「API Keys」页面
3. 点击「创建 API Key」，复制 `{id}.{secret}` 格式的 Key
